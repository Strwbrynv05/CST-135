package com.example.mathquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btn_start, btn_answer0, btn_answer1, btn_answer2, btn_answer3;
    TextView tv_score, tv_questions, tv_timer, tv_answer;
    ProgressBar prog_timer;

    Game g = new Game;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_start = (Button) findViewById(R.id.btn_start);
        btn_answer0 = (Button) findViewById(R.id.btn_answer0);
        btn_answer1 = (Button) findViewById(R.id.btn_answer1);
        btn_answer2 = (Button) findViewById(R.id.btn_answer2);
        btn_answer3 = (Button) findViewById(R.id.btn_answer3);

        tv_score = (TextView) findViewById(R.id.tv_score);
        tv_questions = (TextView) findViewById(R.id.tv_questions);
        tv_timer = (TextView) findViewById(R.id.tv_timer);
        tv_answer = (TextView) findViewById(R.id.tv_answer);

        tv_timer.setText("0Sec");
        tv_questions.setText("");
        tv_answer.setText("Press Go");
        tv_score.setText("0pts");
        prog_timer.setProgress(0);

        prog_timer = (ProgressBar) findViewById(R.id.prog_timer);

        View.OnClickListener startButtonClickListner = new View.OnClickListener() {
            @Override
            public void onClick (View v){
                Button start_button = (Button) v;

                start_button.setVisibility(View.INVISIBLE);
                nextTurn();
            }
        };

        View.OnClickListener answerButtonClickListner = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button buttonClicked = (Button) v;

                int answerSelected = Integer.parseInt(buttonClicked.getText().toString());
            }
        };

            btn_start.setOnClickListener(startButtonClickListner);

            btn_answer0.setOnClickListener(answerButtonClickListner);
            btn_answer1.setOnClickListener(answerButtonClickListner);
            btn_answer2.setOnClickListener(answerButtonClickListner);
            btn_answer3.setOnClickListener(answerButtonClickListner);


    }

    private void nextTurn() {
        g.makeNewQuestion();
        int [] answer = g.getCurrentQuestion().getAnswerArray();
        btn_answer0.setText(Integer.toString(answer[0]));
        btn_answer1.setText(Integer.toString(answer[1]));
        btn_answer2.setText(Integer.toString(answer[2]));
        btn_answer3.setText(Integer.toString(answer[3]));

        btn_answer0.setEnabled(true);
        btn_answer1.setEnabled(true);
        btn_answer2.setEnabled(true);
        btn_answer3.setEnabled(true);

        //tv_questions.setText(g.getCurrentQuestion().getQuestionPhrase());




    }
}
