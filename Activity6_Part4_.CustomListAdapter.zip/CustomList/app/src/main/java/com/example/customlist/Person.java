package com.example.customlist;

public class Person {

    private String name;
    private int age;
    private int picturenumber;

    public Person(String name, int age, int picturenumber) {
        this.name = name;
        this.age = age;
        this.picturenumber = picturenumber;

    }

        //compare to sorting
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getPicturenumber() {
        return picturenumber;
    }

    public void setPicturenumber(int picturenumber) {
        this.picturenumber = picturenumber;
    }
}
