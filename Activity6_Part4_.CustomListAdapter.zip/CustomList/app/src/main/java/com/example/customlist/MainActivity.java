package com.example.customlist;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    Button btn_add, btn_sort, btn_sortAge;

    ListView lv_firendsList;

    PersonAdapter adapter;

    MyFriends myFriends;


    ArrayAdapter ad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_add = findViewById(R.id.btn_add);
        btn_sort = findViewById(R.id.btn_sort);
        btn_sortAge = findViewById(R.id.btn_sortAge);
        lv_firendsList = findViewById(R.id.lv_friendslist);

       myFriends = new MyFriends();

       adapter = new PersonAdapter(MainActivity.this.myFriends);

       lv_firendsList.setAdapter(adapter);


        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }

        });



    }
}