package com.example.jokeapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btn1_Joke1, btn2_Joke2, btn3_Joke3, btn4_Joke4, btn5_Joke5, btn6_Joke6;

    TextView tv_message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn1_Joke1 = findViewById(R.id.btn1_Joke1);
        btn2_Joke2 = findViewById(R.id.btn2_Joke2);
        btn3_Joke3 = findViewById(R.id.btn3_Joke3);
        btn4_Joke4 = findViewById(R.id.btn4_Joke4);
        btn5_Joke5 = findViewById(R.id.btn5_Joke5);
        btn6_Joke6 = findViewById(R.id.btn6_Joke6);

        tv_message = findViewById(R.id.tv_message);

        //Create Click listner

        btn1_Joke1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "To get to the other side", Toast.LENGTH_SHORT).show();
            }
        });

        btn2_Joke2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Bison", Toast.LENGTH_SHORT).show();
            }
        });

        btn3_Joke3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Red Paint", Toast.LENGTH_SHORT).show();
            }
        });

        // JOkes 4 5 and 6 will use the text view to display the answer

        btn4_Joke4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv_message.setText("B");
            }
        });
        btn5_Joke5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv_message.setText("An impasta");
            }
        });

        btn6_Joke6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv_message.setText("A rainbow");
            }
        });
    }
}
