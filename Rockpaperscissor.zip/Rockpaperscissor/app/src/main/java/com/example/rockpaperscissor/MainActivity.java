package com.example.rockpaperscissor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    Button btn_rock, btn_scissors, btn_paper;
    TextView tv_comp, tv_human, tv_score;
    ImageView iv_Comp, iv_human;
    int HumanScore, Computerscore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_paper = (Button) findViewById(R.id.btn_paper);
        btn_rock = (Button) findViewById(R.id.btn_rock);
        btn_scissors = (Button) findViewById(R.id.btn_scissors);

        iv_Comp = (ImageView) findViewById(R.id.iv_comp);
        iv_human = (ImageView) findViewById(R.id.iv_human);

        tv_score = (TextView) findViewById(R.id.tv_score);

        btn_rock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iv_human.setImageResource(R.drawable.rock2);
                String message = play_turn("Rock");
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
                tv_score.setText("Score Human: " + Integer.toString(HumanScore) + "Computer: " + Integer.toString(Computerscore));
            }
        });

        btn_paper.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iv_human.setImageResource(R.drawable.paper2);
                String message = play_turn("Paper");
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
                tv_score.setText("Score Human: " + Integer.toString(HumanScore) + "Computer: " + Integer.toString(Computerscore));
            }
        });

        btn_scissors.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iv_human.setImageResource(R.drawable.scissors2);
                String message = play_turn("Scissors");
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
                tv_score.setText("Score Human: " + Integer.toString(HumanScore) + "Computer: " + Integer.toString(Computerscore));
            }
        });
    }

    public String play_turn(String player_choice) {
        String computer_choice = "";
        Random r = new Random();
        int computer_choice_number = r.nextInt(3) + 1;

        if(computer_choice_number == 1 ) {
            computer_choice = "rock";
        } else
        if(computer_choice_number == 2 ) {
            computer_choice = "paper";
        } else
        if(computer_choice_number == 3 ) {
            computer_choice = "scissors";
        }

        if(computer_choice == "rock" ) {
           iv_Comp.setImageResource(R.drawable.rock2);
        } else
        if(computer_choice == "paper" ) {
            iv_Comp.setImageResource(R.drawable.paper2);
        } else
        if(computer_choice == "scissors" ) {
            iv_Comp.setImageResource(R.drawable.scissors2);
        }

        if(computer_choice == player_choice ) {
            return "draw. Nobody won. Try again.";
        } else
        if(player_choice == "rock" && computer_choice == "scissors" ) {
            HumanScore++;
            return "Rock wins. Rock crushes scisssors. " ;

        } else
        if(player_choice == "rock" && computer_choice == "paper" ) {
            Computerscore++;
            return "paper covers rock. Paper wins.. " ;

        } else
        if(player_choice == "scissors" && computer_choice == "rock" ) {
            Computerscore++;
            return "Rock wins. Rock crushes scisssors. " ;

        } else
        if(player_choice == "paper" && computer_choice == "rock" ) {
            HumanScore++;
            return "Rock wins. Rock covers paper. " ;

        } else
        if(player_choice == "paper" && computer_choice == "scissors" ) {
            Computerscore++;
            return "scissors cut paper. AI wins!. " ;

        } else
        if(player_choice == "paper" && computer_choice == "scissors." ) {
            HumanScore++;
            return "Scissors cut paper. You win!. " ;
        }
        else return "not sure";
    }
}
